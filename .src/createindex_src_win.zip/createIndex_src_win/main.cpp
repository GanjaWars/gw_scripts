#include <vcl.h>
#include <iostream>
#include <fstream>
#include <string>

//mylib
#include "addlib.h"

#include "main.h"

#pragma hdrstop
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner) {}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender) {Form1->Close();}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender) {
	AnsiString rez;

	if (! DirectoryExists("src")) {
		rez = "���������� src �� ��������� �� �������...";
		before_close(rez, 1);
		return;
	}

	TSearchRec f;
	int r = FindFirst("src\\*.user.js", faAnyFile, f);

	if (r) {
		rez = "� ���������� src �������� �� �������...";
		before_close(rez, 1);
		return;
	}

	int count = 0;
	string sbuf;
	string strfind1 = "@name";
	string strfind2 = "@description";
	AnsiString fname, path, name, description;

	fstream index;
	index.open("index.html", ios::out);

	index	<< "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n"
			<< "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"ru\" xml:lang=\"ru\">\n<head>\n"
			<< "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=cp1251\" />\n<title>������ ��������</title>\n"
			<< "<style type=\"text/css\">\ndiv {margin: 0 0 5px 0; font-size: 12px;}\na {font-weight: bold;}\n"
			<< "</style>\n<script type=\"text/javascript\">\nvar list = [];\n";

	while (!r) {
		fname = f.Name;
		Form1->Label1->Caption = fname;

		path = "src\\" + fname;
		ifstream fRead(path.c_str(), ios::in);

		name = "";
		description = "";
		int pos;
		if (fRead.is_open()) {
			fRead.seekg(0);
			while (getline(fRead, sbuf, '\n'), !fRead.eof()) {
				if (name != "" && description != "") break;
				if (sbuf.empty()) continue;

				if (name == "" && ((pos = sbuf.find(strfind1)) != -1) && sbuf.find("@namespace") == -1) {
					parseStr(sbuf, pos, strfind1, name);
				} else if (description == "" && ((pos = sbuf.find(strfind2)) != -1)) {
					parseStr(sbuf, pos, strfind2, description);
				} else if (sbuf.find("==/UserScript==", 0) != -1) {
					break;
				}
			}

			fRead.close();
		}

		if (name != "" && description != "") {
			name = Utf8ToAnsi(name);
			description = Utf8ToAnsi(description);
			index << "list[" << count << "] = [\"" << fname.c_str() << "\",\"" << name.c_str() << "\",\"" << description.c_str() << "\"];" << endl;
			count++;
		}

		r = FindNext(f);
	}

	index	<< "function addScriptDescription() {\nfor (var i = 0; i < list.length; i++) {\nvar div = document.createElement(\"div\");\n"
			<< "div.innerHTML = '<a target=\"_blank\" href=\"src/' + list[i][0] + '\">' + list[i][1] + '</a><br>' + list[i][2];\n"
			<< "document.body.appendChild(div);\n}\n}\n</script>\n</head>\n<body>\n<script type=\"text/javascript\">"
			<< "addScriptDescription();</script>\n</body>\n</html>";

	index.close();

	if (!count) {
		rez = "�� ������� �������� ��� �������� ��������.";
		before_close(rez, 1);
	} else {
		rez = "���� index.html ������� ������.\n������� �������� ";
		rez += count;
		rez += " ��������.";
		before_close(rez);
	}
}

