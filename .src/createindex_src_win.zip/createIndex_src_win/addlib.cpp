#include <main.h>
#include <string>

#include "addlib.h"

#pragma hdrstop
#pragma package(smart_init)

//---------------------------------------------------------------------------
void parseStr(string str, int pos, const string strfind, AnsiString &s) {
	s = str.c_str();
	s = s.SubString(pos + strfind.length() + 1, s.Length());
	s = s.Trim();
	s = StringReplace(s, "\"", "`", TReplaceFlags() << rfReplaceAll);
}
//---------------------------------------------------------------------------
void before_close(AnsiString str, int del) {
	Form1->Label1->Caption = str;
	Form1->Button1->Visible = false;
	Form1->Button2->Visible = true;
	if (del) {
		AnsiString FileName="index.html";
		DeleteFile(FileName);
	}
}
//---------------------------------------------------------------------------

