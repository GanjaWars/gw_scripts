#ifndef addlibH
#define addlibH

using namespace std;
void parseStr(string str, int pos, const string strfind, AnsiString &s);
void before_close(AnsiString str, int del = 0);

#endif
