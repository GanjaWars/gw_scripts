#include <string>
#include <iconv.h>
using namespace std;

//------------------------------------------------------------------------------
void parseStr(string &s, int pos, const string strfind) {
    s = s.c_str();
    s = s.substr(pos + strfind.length(), s.length());

    for (string::iterator it = s.begin(); it < s.end(); ++it) {
        if (*it == '\t' || (it == s.begin() && *it == ' ') || (int)(*it) == 13) {
            s.erase(it);
            it--;
        } else if (*it == ' ' && *(it + 1) == ' ') {
            s.erase(it);
            s.erase(it);
            it -= 2;
        } else if (*it == '"') {
            *it = '`';
        }
    }
}
//------------------------------------------------------------------------------
string iconv_recode(string from, string to, string text) {

    iconv_t cnv = iconv_open(to.c_str(), from.c_str());
    char *outbuf = new char[text.length() * 2 + 1];

    //(iconv_t) - 1 == 0xffffffff
    if ((cnv == (iconv_t) - 1) || outbuf  == NULL) {
        iconv_close(cnv);
        return "";
    }

    size_t icount = text.length();
    size_t ocount = icount * 2;

    char *ip = (char *)text.c_str();
    //так надо:) &op и &outbuf при проверке в дебаггере содержат один и тот же адрес,
    //но после вызова iconv разный => хз
    char *op = outbuf;

    if (iconv(cnv, &ip, &icount, &op, &ocount) != (size_t) - 1) {
        outbuf[text.length() * 2 - ocount] = '\0';
        text = outbuf;
    } else {
        text = "";
    }

    delete(outbuf);
    iconv_close(cnv);

    return text;
}
