#ifndef ADDLIB_H
#define ADDLIB_H

using namespace std;
void parseStr(string &s, int pos, const string strfind);
string iconv_recode(string from, string to, string text);

#endif // ADDLIB_H
