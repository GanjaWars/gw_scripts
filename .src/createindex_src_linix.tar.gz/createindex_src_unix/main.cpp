#include <dirent.h>
#include <iostream>
#include <fstream>

//mylib
#include "addlib.h"

//на время отладки
//pop g++ diagnostic flags, disable some flags and push
// [warning: comparison between signed and unsigned integer expressions [-Wsign-compare]]
//#pragma GCC diagnostic pop
//#pragma GCC diagnostic ignored "-Wsign-compare"
//#pragma GCC diagnostic push

int main() {
    DIR *dir = opendir("src");
    fstream index;
    string fname;
    int count = 0;

    if (dir) {
        string strfind1 = "@name", strfind2 = "@description", utf_8 = "UTF-8", cp_1251 = "CP1251", title = "Список скриптов";
        string path, sbuf, name, description;
        int pos;

        struct dirent *ent;
        while((ent = readdir(dir)) != NULL) {
            fname = ent->d_name;
            if (fname.find(".user.js") != -1) {

                if (!index.is_open()) {
                    index.open("index.html", ios::out);
                    index	<< "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n"
                            << "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"ru\" xml:lang=\"ru\">\n<head>\n"
                            << "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=cp1251\" />\n"
                            << "<title>" << iconv_recode(utf_8, cp_1251, title)
                            << "</title>\n<style type=\"text/css\">\ndiv {margin: 0 0 5px 0; font-size: 12px;}\na {font-weight: bold;}\n"
                            << "</style>\n<script type=\"text/javascript\">\nvar list = [];\n";
                }

                name = "";
                description = "";
                path = "src/" + fname;
                ifstream fRead(path.c_str(), ios::in);

                if (fRead.is_open()) {
                    fRead.seekg(0);
                    while (getline(fRead, sbuf, '\n'), !fRead.eof()) {
                        if (name != "" && description != "") break;
                        if (sbuf.empty()) continue;

                        if (name == "" && ((pos = sbuf.find(strfind1)) != -1) && sbuf.find("@namespace") == -1) {
                            parseStr(sbuf, pos, strfind1);
                            name = sbuf;
                        } else if (description == "" && (pos = sbuf.find(strfind2)) != -1) {
                            parseStr(sbuf, pos, strfind2);
                            description = sbuf;
                        } else if (sbuf.find("==/UserScript==") != -1) {
                            break;
                        }
                    }

                    fRead.close();
                }

                if (name != "" && description != "") {
                    index   << "list[" << count << "]=[\"" << fname << "\",\"" << iconv_recode(utf_8, cp_1251, name)
                            << "\",\"" << iconv_recode(utf_8, cp_1251, description) << "\"];\n";
                    count++;
                }
            }
        }


        if (!count) {
            if (index.is_open()) index.close();
            remove("index.html");
            cout << "В директории src не найдено ни одного скрипта...\n";
        } else {
            index	<< "function addScriptDescription() {\nfor (var i = 0; i < list.length; i++) {\nvar div = document.createElement(\"div\");\n"
                    << "div.innerHTML = '<a target=\"_blank\" href=\"src/' + list[i][0] + '\">' + list[i][1] + '</a><br>' + list[i][2];\n"
                    << "document.body.appendChild(div);\n}\n}\n</script>\n</head>\n<body>\n<script type=\"text/javascript\">addScriptDescription();</script>\n"
                    << "</body>\n</html>";

            index.close();
            cout << "Файл index.html успешно создан.\nНайдено описание " << count << " скриптов.\n";
        }
    } else {
        remove("index.html");
        cout << "Директория src не найдена\n";
    }

    closedir(dir);
    return 0;
}
